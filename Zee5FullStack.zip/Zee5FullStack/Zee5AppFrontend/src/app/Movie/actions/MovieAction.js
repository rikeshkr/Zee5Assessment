import {
  ADD_Movie,
  DELETE_Movie,
  GET_MovieS,
  GET_Movie_BY_TYPE,
  GET_Movie_DETAILS,
  UPDATE_Movie,
} from "../../../redux/actionsTypes";
import api from "../../../utils/api";
import { setAlert } from "../../core/actions/alertAction";

//Fetch all Movies
export const getAllMovies = () => async (dispatch) => {
  try {
    const res = await api().get("/Movie/");
    dispatch({ type: GET_MovieS, payload: res.data });
  } catch (error) {
    dispatch(setAlert(error.response.data.message, "danger"));
  }
};

//fetch Movie of specific type
export const getMovieByType = (type) => async (dispatch) => {
  try {
    const res = await api().get("/Movie/" + type);
    dispatch({ type: GET_Movie_BY_TYPE, payload: res.data });
  } catch (error) {
    dispatch(setAlert(error.response.data.message, "danger"));
  }
};

//update Movie item
export const editMovie = (formData, id) => async (dispatch) => {
  try {
    const res = await api().put(`/Movies/${id}`, formData);
    dispatch({ type: UPDATE_Movie, payload: res.data });
    dispatch(setAlert("You edited Movie Item successfully.", "success"));
    dispatch(getAllMovies());
  } catch (error) {
    dispatch(setAlert(error.response.data.message, "danger"));
  }
};

//get complete Movie details
export const getMovie = (id) => async (dispatch) => {
  try {
    const res = await api().get(`/Movies/${id}`);
    dispatch({ type: GET_Movie_DETAILS, payload: res.data });
  } catch (error) {
    dispatch(setAlert(error.response.data.message, "danger"));
  }
};

//creating Movie
export const createMovie = (formData, navigate) => async (dispatch) => {
  try {
    const res = await api().post("/Movie", formData);
    dispatch({ type: ADD_Movie, payload: res.data });
    navigate("/Movie");
    //update Movies store after adding Movie
    dispatch(getAllMovies());
    dispatch(setAlert("You Added Movie Item successfully.", "success"));
  } catch (err) {
    const res = err.response.data;
    if (res.subErrors) {
      res.subErrors.forEach((error) =>
        dispatch(setAlert(error.field + " " + error.message, "danger"))
      );
    } else {
      dispatch(setAlert(res.message, "danger"));
    }
  }
};

//deleting Movie
export const deleteMovie = (id) => async (dispatch) => {
  try {
    const res = await api().delete(`/Movies/${id}`);
    // action to delete Movie
    dispatch({ type: DELETE_Movie, payload: null });
    //action to update the Movies array in store
    dispatch(getAllMovies());
    dispatch(setAlert("Deleted Movie", "danger"));
  } catch (error) {
    dispatch(setAlert(error.response.data.message, "danger"));
  }
};
