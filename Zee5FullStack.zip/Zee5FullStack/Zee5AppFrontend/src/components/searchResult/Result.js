import PropTypes from "prop-types";
import React, { useEffect } from "react";
import { connect } from "react-redux";
import { Link, useNavigate, useParams } from "react-router-dom";
import { getMovieByName } from "../../redux/actions/movieAction";
import MovieResult from "./MovieResult";
import SeriesResult from "./SeriesResult";

const Result = ({ movie: { movie }, series: { serie }, getMovieByName }) => {
  const navigate = useNavigate();

  return (
    <div className="profile-exp bg-white p-2">
      <div className="card bg-light m-2">
        {movie ? (
          <MovieResult
            key={movie && movie[0].movieId}
            movieId={movie && movie[0].movieId}
            movieName={movie && movie[0].movieName}
            actors={movie && movie[0].actors}
            genre={movie && movie[0].genre}
            director={movie && movie[0].director}
            languages={movie && movie[0].languages}
            production={movie && movie[0].production}
          />
        ) : (
          serie && (
            <SeriesResult
              key={serie && serie[0].webSeriesId}
              webSeriesId={serie && serie[0].webSeriesId}
              webSeriesName={serie && serie[0].webSeriesName}
              actors={serie && serie[0].actors}
              genre={serie && serie[0].genre}
              director={serie && serie[0].director}
              languages={serie && serie[0].languages}
              production={serie && serie[0].production}
            />
          )
        )}
        {!movie && !serie && <h4>No data found!</h4>}
      </div>
      <Link to="/dashboard" className="btn btn-outline-dark">
        Go Back
      </Link>
    </div>
  );
};

Result.propTypes = {
  movie: PropTypes.object.isRequired,
  series: PropTypes.object.isRequired,
  getMovieByName: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  movie: state.movie,
  series: state.series,
});

const mapDispatchToProps = { getMovieByName };

export default connect(mapStateToProps, mapDispatchToProps)(Result);
