import React from "react";
import { Button } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { deleteMovieById } from "../../redux/actions/movieAction";

const Movie = ({
  movieId,
  movieName,
  actors,
  director,
  languages,
  production,
  genre,
  isAdmin,
}) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const onDelete = () => {
    dispatch(deleteMovieById(movieId, navigate));
  };

  return (
    <div className="card bg-light m-2">
      <div className="card-body">
        <h4>Movie Name: {movieName}</h4>
        <h5>Director: {director}</h5>
        <h5>Genre: {genre}</h5>
        <h5>Production: {production}</h5>
        <h5>Actors: {actors.join()}</h5>
        <h5>Languages: {languages.join()}</h5>
        {isAdmin && (
          <div className="container mt-3">
            <Link
              to={`/update-movie/${movieId}`}
              className="btn btn-success px-5 m-2"
            >
              Update
            </Link>
            <button className="btn btn-danger px-5" onClick={onDelete}>
              Delete
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Movie;
