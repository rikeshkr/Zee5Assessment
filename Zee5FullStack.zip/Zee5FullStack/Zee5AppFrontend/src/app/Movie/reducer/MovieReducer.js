import {
  ADD_MOVIE,
  GET_MOVIES,
  UPDATE_MOVIE,
  DELETE_MOVIE,
  GET_MOVIE_BY_TYPE,
  GET_MOVIE_DETAILS,
} from "../../../redux/actionsTypes";

const initialState = {
  Movies: null,
  currentMovie: null,
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case GET_MOVIES:
    case GET_MOVIE_BY_TYPE:
      //above actions have similar behavior and updates the same field of the state
      return {
        ...state,
        Movies: payload,
      };
    case GET_MOVIE_DETAILS:
    case UPDATE_MOVIE:
    case DELETE_MOVIE:
      //above cases have same behavior and updates the state of currentMovie
      //in case of delete, action sends null as payload
      return {
        ...state,
        currentMovie: payload,
      };
    case ADD_MOVIE:
    //in case of add admin is redirected to dashboard and alert is rendered to know the status
    default:
      return state;
  }
};
