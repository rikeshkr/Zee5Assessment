import logo from "./logo.svg";
import "./App.css";
import Navbar from "./components/layouts/Navbar";
import Landing from "./components/layouts/Landing";
import Footer from "./components/layouts/Footer";
import { Routings } from "./components/routing/Routings";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import store from "./redux/store";
import setAuthToken from "./utils/setAuthToken";
import { useEffect } from "react";
import { loaduser } from "./redux/actions/authAction";

if (localStorage.token) {
  setAuthToken(localStorage.token);
}

function App() {
  useEffect(() => {
    if (localStorage.token) store.dispatch(loaduser());
    //explicitly calling the load user
  }, []); // whenever the component is updated or refreshed rt then useEffect will be called

  return (
    <Provider store={store}>
      <div className="App">
        <BrowserRouter>
          <Navbar />
          <Routings />
          <Footer />
        </BrowserRouter>
      </div>
    </Provider>
  );
}

export default App;
