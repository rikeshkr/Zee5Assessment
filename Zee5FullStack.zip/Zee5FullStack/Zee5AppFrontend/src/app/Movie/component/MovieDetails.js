import PropTypes from "prop-types";
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { Link, useParams } from "react-router-dom";
import store from "../../../redux/store";
import { getmovie, deletemovie } from "../actions/MovieAction";
export const movieDetails = ({
  movie: { currentmovie },
  auth: { userInfo },
  cart,
  getmovie,
  deletemovie,
}) => {
  const { id } = useParams();
  useEffect(() => {
    //fetch movie based on id in the url
    if (!currentmovie) {
      getmovie(id);
      fetchFromCart();
    }
  }, [currentmovie, id, getmovie]);

  //check whether movie item is in cart or not
  const [inCart, setInCart] = useState(
    cart.filter((item) => item.id === currentmovie.id).length > 0 ? true : false
  );

  //if movie id is invalid
  if (!currentmovie) {
    return (
      <div
        className="text-center"
        style={{ marginBottom: "200px", marginTop: "100px" }}
      >
        <h1 className="text text-center">movie doesn't exist</h1>
      </div>
    );
  }
  const isAdmin =
    userInfo && userInfo.roles && userInfo.roles.includes("ROLE_ADMIN")
      ? true
      : false;

  return (
    <div className="row movie-details-container m-5">
      <div className="col">
        <img
          src={currentmovie.moviePic}
          alt={currentmovie.movieName}
          className="img-thumbnail"
          style={{ maxHeight: "unset", maxWidth: "unset" }}
        />
      </div>
      <div className="col">
        <h3>{currentmovie.movieName}</h3>
        <h1>₹ {currentmovie.movieCost}</h1>
        <div>{currentmovie.description}</div>

        {isAdmin ? (
          // if admin, show the options to delete and edit movie
          <div className="button-container mt-5">
            <Link
              className="btn btn-primary m-3"
              to={`/admin/editmovie/${currentmovie.id}`}
            >
              <i className="bi bi-pencil-square"></i>
              Edit movie
            </Link>
            <Link
              to="/movie"
              className="btn btn-danger m-3"
              onClick={(e) => {
                deletemovie(currentmovie.id);
              }}
            >
              <i className="bi bi-trash"></i>
              Delete movie
            </Link>
          </div>
        ) : (
          //if customer or non-authenticated show add to cart/remove from cart
          <button
            className={`btn btn-${inDB ? "danger" : "info"} mt-5`}
            onClick={(e) => {
              if (e.target.innerText === "Add to Database") {
                store.dispatch(addToDB(currentmovie));
              } else {
                store.dispatch(removeFromDB(currentmovie.id));
              }
            }}
          ></button>
        )}
      </div>
    </div>
  );
};

movieDetails.propTypes = {
  auth: PropTypes.object.isRequired,
  movie: PropTypes.object.isRequired,
  deletemovie: PropTypes.func.isRequired,
  getmovie: PropTypes.func.isRequired,
  cart: PropTypes.array.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
  movie: state.movie,
  cart: state.cart,
});

const mapDispatchToProps = { getmovie, deletemovie };

export default connect(mapStateToProps, mapDispatchToProps)(movieDetails);
