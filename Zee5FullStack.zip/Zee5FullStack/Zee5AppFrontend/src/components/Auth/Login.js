import PropTypes from "prop-types";
import React, { Fragment, useState } from "react";
import { connect } from "react-redux";
import { Link, Navigate } from "react-router-dom";
import { login } from "../../redux/actions/authAction";

const Login = ({ login, isAuthenticated }) => {
  const myStyle = {
    backgroundImage:
      "url('https://www.thefastmode.com/media/k2/items/src/68dfc5056ce08a29895578303d864463.jpg?t=20220126_070228')",
    height: "100vh",
    //   marginTop: "-70px",
    // fontSize: "22px",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
  };

  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });
  const { username, password } = formData;

  const onSubmit = (e) => {
    e.preventDefault();
    login({ username, password });
  };

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  if (isAuthenticated === true) {
    return <Navigate to="/dashboard" />;
  }

  return (
    <Fragment>
      <section className="landing">
        <div className="dark-overlay p-5" style={myStyle}>
          <p className="col-6 text-light">
            <i className="fas fa-user"></i> Sign Into Your Account
          </p>
          <form className="form my-4" onSubmit={onSubmit}>
            <div className="mb-3 col-6">
              <label className="form-label text-light">Username</label>
              <input
                type="text"
                name="username"
                className="form-control"
                id="username"
                aria-describedby="emailHelp"
                value={username}
                onChange={onChange}
                required
              />
            </div>
            <div className="mb-5 col-6">
              <label className="form-label text-light">Password</label>
              <input
                type="password"
                name="password"
                className="form-control"
                id="password"
                value={password}
                onChange={onChange}
                required
              />
            </div>

            <div className="col-6">
              <button type="submit" className="btn btn-primary px-5">
                Login
              </button>
            </div>
          </form>
          <p className="col-6 text-light my-5">
            Don't have an account? <Link to="/register">Sign Up</Link>
          </p>
        </div>
      </section>
    </Fragment>
  );
};

Login.propTypes = {
  login: PropTypes.func.isRequired,
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = { login };

export default connect(mapStateToProps, mapDispatchToProps)(Login);
