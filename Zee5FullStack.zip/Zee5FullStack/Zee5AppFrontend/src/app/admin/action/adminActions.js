import { DELETE_User, GET_UserS } from "../../../redux/actionsTypes";
import api from "../../../utils/api";
import { setAlert } from "../../core/actions/alertAction";

//admin deleting User by id
export const deleteUser = (id) => async (dispatch) => {
  try {
    const res = await api().delete(`/users/${id}`);
    dispatch({ type: DELETE_User, payload: res.data });
    dispatch(setAlert("Deleted User", "danger"));
    //using action to update the store after deleting a User
    dispatch(getUsers());
  } catch (error) {
    //setting up alerts in case of error
    dispatch(setAlert(error.response.data.message, "danger"));
  }
};

//getting all users data
export const getUsers = () => async (dispatch) => {
  try {
    const res = await api().get(`/users`);
    //action to fetch users data
    dispatch({ type: GET_USERS, payload: res.data });
  } catch (error) {
    console.log(error);
    dispatch(setAlert(error.response.data.message, "danger"));
  }
};
