// 1. we have to make entries of all available reducers at one place ---> index.js
// 2. we have registered al reducers using combineReducers() method.

import { combineReducers } from "redux";
import auth from "./authReducer";
import alerts from "./alertReducer";
import profile from "./profileReducer";
import post from "./postReducer";
import movie from "./movieReducer";
import series from "./seriesReducer";

export default combineReducers({ auth, alerts, profile, post, movie, series });
