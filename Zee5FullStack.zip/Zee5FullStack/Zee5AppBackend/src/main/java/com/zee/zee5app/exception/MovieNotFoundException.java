package com.zee.zee5app.exception;

public class MovieNotFoundException extends Exception {
	public MovieNotFoundException(String msg) {
		super(msg);
	}
}
