import React from "react";
import Moment from "react-moment";

const DisplayEducation = ({ education }) => {
  const educations = education.map((e) => (
    <tr key={e._id}>
      <td>{e.school}</td>
      <td class="hide-sm">{e.degree}</td>
      <td class="hide-sm">{e.fieldofstudy}</td>
      <td class="hide-sm">
        <Moment format="DD-MM-YYYY">{e.from}</Moment> -{" "}
        {e.to ? <Moment format="DD-MM-YYYY">{e.to}</Moment> : "Now"}
      </td>
      <td>
        <button class="btn btn-danger">Delete</button>
      </td>
    </tr>
  ));

  return (
    <div>
      {" "}
      <h2 class="my-2">Education Credentials</h2>
      <table class="table">
        <thead>
          <tr>
            <th>School</th>
            <th class="hide-sm">Degree</th>
            <th class="hide-sm">Field of Study</th>
            <th class="hide-sm">Years</th>
          </tr>
        </thead>
        <tbody>{educations}</tbody>
      </table>
    </div>
  );
};

export default DisplayEducation;
