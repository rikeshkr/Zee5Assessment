import PropTypes from "prop-types";
import React from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { Fragment } from "react";

const MovieDashboard = ({ auth: { user } }) => {
  const myStyle = {
    backgroundImage:
      "url('https://www.thefastmode.com/media/k2/items/src/68dfc5056ce08a29895578303d864463.jpg?t=20220126_070228')",
    height: "100vh",
    //   marginTop: "-70px",
    // fontSize: "22px",
    backgroundSize: "100% 100%",
    backgroundRepeat: "no-repeat",
  };

  var flag = null;
  if (user.roles === "ROLE_ADMIN") flag = true;

  return (
    <Fragment>
      <div className="dark-overlay" style={myStyle}>
        <div className="container">
          <Link
            to="/get-movies"
            className="btn btn-success px-5 me-4"
            style={{ marginTop: "200px" }}
          >
            Get Movies
          </Link>
          {flag && (
            <Link
              to="/add-movie"
              className="btn btn-success px-5"
              style={{ marginTop: "200px" }}
            >
              Add Movie
            </Link>
          )}
        </div>
      </div>
    </Fragment>
  );
};

MovieDashboard.propTypes = {
  auth: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(MovieDashboard);
