import React from "react";
import { Link, Navigate } from "react-router-dom";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import Heading from "./Heading";

const Landing = ({ isAuthenticated }) => {
  const myStyle = {
    backgroundImage:
      "url('https://www.thefastmode.com/media/k2/items/src/68dfc5056ce08a29895578303d864463.jpg?t=20220126_070228')",
    height: "100vh",
    //   marginTop: "-70px",
    fontSize: "50px",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
  };

  if (isAuthenticated) {
    return <Navigate to="/dashboard" />;
  }

  return (
    <div>
      <section className="landing">
        <div className="dark-overlay" style={myStyle}>
          <Heading />
        </div>
      </section>
    </div>
  );
};

Landing.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

export default connect(mapStateToProps)(Landing);
