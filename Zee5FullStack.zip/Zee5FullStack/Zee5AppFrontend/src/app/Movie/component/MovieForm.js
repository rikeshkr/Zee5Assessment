import PropTypes from "prop-types";
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { useMatch, useParams } from "react-router-dom";
import { editMovie, getMovie, createMovie } from "../actions/MovieAction";
import { useNavigate } from "react-router-dom";

export const MovieForm = ({
  editMovie,
  getMovie,
  createMovie,
  Movie: { currentMovie },
}) => {
  const [formData, setFormData] = useState({
    foodName: "",
    MovieCost: "",
    MoviePic: "",
    MovieType: "Indian",
    description: "",
  });
  const { MovieName, MovieCost, MoviePic, MovieType, description } = formData;

  const { id } = useParams();
  //check whether the action is add/ update based on the url matches
  const isCreate = useMatch("/admin/addMovie");
  const navigate = useNavigate();
  useEffect(() => {
    //load existing info if it is edit
    if (currentMovie && !isCreate) {
      setFormData(currentMovie);
    } else if (!currentMovie && id) {
      getMovie(id);
    }
  }, [getMovie, currentMovie, id]);

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const onSubmit = (e) => {
    e.preventDefault();
    if (isCreate) {
      createMovie(
        { MovieName, MovieCost, MoviePic, MovieType, description },
        navigate
      );
    } else {
      editMovie({ MovieName, MovieCost, MoviePic, MovieType, description }, id);
    }
  };

  return (
    <div className="container mt-4">
      <div className="col">
        <h3>{isCreate ? "Add " : "Edit "}Movie details</h3>
        <form onSubmit={onSubmit}>
          <div className="mb-3">
            <label htmlFor="MovieName" className="form-label">
              Movie name
            </label>
            <input
              type="text"
              className="form-control"
              id="MovieName"
              name="MovieName"
              onChange={onChange}
              value={MovieName}
              aria-describedby="MovieNameHelp"
            />
          </div>
          <div className="mb-3">
            <label htmlFor="MovieCost" className="form-label">
              Movie cost
            </label>
            <div className="input-group mb-3">
              <span className="input-group-text">₹</span>
              <input
                type="number"
                className="form-control"
                id="MovieCost"
                name="MovieCost"
                onChange={onChange}
                value={MovieCost}
                aria-label="Amount (to the nearest INR)"
              />
              <span className="input-group-text">.00</span>
            </div>
          </div>
          <div className="mb-3">
            <label htmlFor="MovieDesc" className="form-label">
              Movie description
            </label>
            <textarea
              className="form-control"
              id="MovieDesc"
              name="description"
              onChange={onChange}
              value={description}
              rows="5"
              maxLength="150"
              aria-describedby="MovieDescHelp"
            ></textarea>
          </div>
          <div className="mb-3">
            <label htmlFor="MoviePic" className="form-label">
              Movie picture URL
            </label>
            <input
              type="web"
              className="form-control"
              id="MoviePic"
              name="MoviePic"
              onChange={onChange}
              value={MoviePic}
              aria-describedby="MoviePicHelp"
            />
          </div>
          <div className="mb-3">
            <label htmlFor="MoviePic" className="form-label">
              Movie type
            </label>
            <select
              className="form-select"
              name="MovieType"
              onChange={onChange}
              value={MovieType}
            >
              <option value="Indian">INDIAN</option>
              <option value="Bollywood">BOLLYWOOD</option>
              <option value="Tollywood">TOLLYWOOD</option>
            </select>
          </div>

          <div className="text-center">
            <button type="submit" className="btn btn-primary">
              {isCreate ? "Add Movie" : "Update Movie"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

MovieForm.propTypes = {
  editMovie: PropTypes.func.isRequired,
  getMovie: PropTypes.func.isRequired,
  createMovie: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  Movie: state.Movie,
});

const mapDispatchToProps = { editMovie, getMovie, createMovie };

export default connect(mapStateToProps, mapDispatchToProps)(MovieForm);
