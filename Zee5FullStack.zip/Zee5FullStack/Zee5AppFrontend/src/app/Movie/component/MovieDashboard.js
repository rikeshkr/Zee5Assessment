import PropTypes from "prop-types";
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { getAllMovies, getMovieByType } from "../actions/MovieAction";
import "../style/Dashboard.css";
import store from "../../../redux/store/index";

//JSX component to render when the movies list is empty
const Nomovies = () => {
  return (
    <div className="text-center">
      <h1>No movies</h1>
      <p>
        There are no movies in the database. Please contact your administrator
      </p>
    </div>
  );
};

//JSX component to render movie details into card in the dashboard
const MovieItem = ({ movie, isAdmin }) => {
  return (
    <div className="card">
      <Link to={`/movie/${movie.id}`}>
        <div className="card-body">
          <h5 className="card-title">{movie.movieName}</h5>
        </div>
        <div className="card-img-container">
          <img
            src={movie.moviePic}
            className="card-img-top col-md-6 col-lg-6 d-inline-block col-sm-4"
            alt={movie.movieName}
            height={"200px"}
          />
        </div>
      </Link>

      {!isAdmin && (
        //show the add to cart if movie not present in the cart for non-admin user
        //and show remove from cart if movie present in the cart for non-admin user
        <button
          className={`btn btn-${inBase ? "danger" : "info"}`}
          onClick={(e) => {
            if (e.target.innerText === "Add to cart") {
              store.dispatch(addToDB(movie));
            } else {
              store.dispatch(removeFromDB(movie.id));
            }
          }}
        ></button>
      )}
    </div>
  );
};

export const movieDashboard = ({
  movie: { movies },
  getAllMovies,
  getMovieByType,
  auth: { userInfo },
  fetchFromDB,
}) => {
  useEffect(() => {
    //update the cart
    if (localStorage.getItem("database")) fetchFromCart();
    //get all movie items
    if (!movies) getAllMovies();
  }, [movies, getAllMovies, fetchFromDB]);
  const isAdmin =
    userInfo && userInfo.roles && userInfo.roles.includes("ROLE_ADMIN");
  const onChange = (e) => {
    //fetch movie details based on the type given by the user
    if (e.target.value === "All") {
      getAllMovies();
    } else {
      getMovieByType(e.target.value);
    }
  };

  return (
    <div className="row main" align="center">
      <div className="row mt-3">
        <div className="col"></div>
        <div className="col"></div>
        <div className="col"></div>
        <div className="col"></div>
        <div className="col">
          <form>
            <select className="form-select" onChange={onChange}>
              <option value="All">All</option>
              <option value="Bollywood">Bollywood</option>
              <option value="Hollywood">Hollywood</option>
              <option value="Tollywood">Tollywood</option>
            </select>
          </form>
        </div>
      </div>

      <div className="grid-container col-md-10 mt-3">
        {/* display movie details is movies are present else Nomovie component is rendered */}
        {movies && movies.length > 0 ? (
          movies.map((movie) => (
            <movieItem
              movie={movie}
              isAdmin={isAdmin}
              key={movie.id}
              cart={cart}
            />
          ))
        ) : (
          <Nomovies />
        )}
      </div>
    </div>
  );
};

movieDashboard.propTypes = {
  movie: PropTypes.object.isRequired,
  getmovieByType: PropTypes.func.isRequired,
  getAllmovies: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
  cart: PropTypes.array.isRequired,
  fetchFromCart: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  movie: state.movie,
  auth: state.auth,
  cart: state.cart,
});

const mapDispatchToProps = { getAllmovies, getmovieByType, fetchFromCart };

export default connect(mapStateToProps, mapDispatchToProps)(movieDashboard);
