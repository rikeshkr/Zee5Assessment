import React, { Component } from "react";
import { Routes, Route } from "react-router-dom";

import Register from "../Auth/Register";
import Register2 from "../Auth/Register2";
import Login2 from "../Auth/Login2";
import Dashboard from "../dashboard/Dashboard";
import Login from "../Auth/Login";
import Alert from "../common/Alert";
import PrivateRoute from "./PrivateRoute";
import CreateProfile from "../Profile/CreateProfile";
import AddExperience from "../Profile/AddExperience";
import AddEducation from "../Profile/AddEducation";
import Landing from "../layouts/Landing";
import Profiles from "../profiles/Profiles";
import ViewProfile from "../displayProfile/ViewProfile";
import Posts from "../posts/Posts";
import Post from "../post/Post";
import FetchMovies from "../Movie/FetchMovies";
import UpdateMovie from "../Movie/UpdateMovie";
import AddMovie from "../Movie/AddMovie";
import MovieDashboard from "../dashboard/MovieDashboard";
import SeriesDashboard from "../dashboard/SeriesDashboard";
import FetchSeries from "../WebSeries/FetchSeries";
import AddSeries from "../WebSeries/AddSeries";
import UpdateSeries from "../WebSeries/UpdateSeries";
import Result from "../searchResult/Result";

export const Routings = () => {
  return (
    <div>
      <Alert></Alert>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/result" element={<PrivateRoute component={Result} />} />
        <Route
          path="/add-movie"
          element={<PrivateRoute component={AddMovie} />}
        />
        <Route
          path="/add-series"
          element={<PrivateRoute component={AddSeries} />}
        />
        <Route
          path="/movie-dashboard"
          element={<PrivateRoute component={MovieDashboard} />}
        />
        <Route
          path="/series-dashboard"
          element={<PrivateRoute component={SeriesDashboard} />}
        />
        <Route
          path="/dashboard"
          element={<PrivateRoute component={Dashboard} />}
        />
        <Route
          path="/create-profile"
          element={<PrivateRoute component={CreateProfile} />}
        />
        <Route
          path="/edit-profile"
          element={<PrivateRoute component={CreateProfile} />}
        />
        <Route
          path="/add-experience"
          element={<PrivateRoute component={AddExperience} />}
        />
        <Route
          path="/add-education"
          element={<PrivateRoute component={AddEducation} />}
        />
        <Route
          path="/get-movies"
          element={<PrivateRoute component={FetchMovies} />}
        />
        <Route
          path="/get-series"
          element={<PrivateRoute component={FetchSeries} />}
        />
        <Route
          path="/update-movie/:id"
          element={<PrivateRoute component={UpdateMovie} />}
        />
        <Route
          path="/update-series/:id"
          element={<PrivateRoute component={UpdateSeries} />}
        />
        <Route path="/posts/:id" element={<PrivateRoute component={Post} />} />
        <Route path="/posts" element={<PrivateRoute component={Posts} />} />
        <Route path="/profiles" element={<Profiles />} />
        <Route path="/profile/:id" element={<ViewProfile />} />
      </Routes>
    </div>
  );
};
