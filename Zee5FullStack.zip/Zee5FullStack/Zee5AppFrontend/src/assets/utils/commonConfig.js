export const headerConfig = {
  headers: { "Content-Type": "application/json" },
};

export const headerConfigAfterLogin = {
  headers: {
    "Content-Type": "application/json",
    Authorization: "Bearer" + `${localStorage.getItem("token")}`,
  },
};
