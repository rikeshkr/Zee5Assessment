//common auth actions
export const LOGIN_SUCCESS = "login success";
export const LOGIN_FAIL = "login fail";
export const REGISTER_SUCCESS = "register success";
export const REGISTER_FAIL = "register fail";
export const LOGOUT = "logout";

//admin auth actions
export const DELETE_CUSTOMER = "delete customer";
export const GET_PROFILE = "get profile";
//customer auth actions
export const GET_CUSTOMERS = "get customers";
export const UPDATE_PROFILE = "update profile";
export const DELETE_ACCOUNT = "delete account";

//alert actions
export const SET_ALERT = "create alert";
export const REMOVE_ALERT = "remove alert";

//admin food actions
export const ADD_MOVIE = "add movie";
export const UPDATE_MOVIE = "update movie";
export const DELETE_MOVIE = "delete movie";

//common food actions
export const GET_MOVIE_DETAILS = "get movie details";
export const GET_MOVIE_BY_TYPE = "get movie by type";
export const GET_MOVIES = "get movies";
