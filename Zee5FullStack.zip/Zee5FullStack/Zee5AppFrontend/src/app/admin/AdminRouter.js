import React from "react";
import { Route, Routes } from "react-router-dom";
import FoodForm from "../Movie/component/MovieDash";
import ViewUsers from "./component/ViewUsers";

const AdminRouter = () => {
  return (
    <Routes>
      <Route path="/users" element={<ViewUsers />} />
      <Route path="/addMovie" element={<MovieForm />} />
      <Route path="/editMovie/:id" element={<MovieForm />} />
    </Routes>
  );
};

export default AdminRouter;
