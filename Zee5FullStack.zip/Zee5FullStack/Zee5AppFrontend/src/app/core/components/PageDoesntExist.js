import React from "react";

//Component to show when user tries to access the invalid resources
const PageDoesntExist = () => {
  return (
    <div className="text text-center mt-5">
      <h2>404 Page Doesnt Exist</h2>
    </div>
  );
};

export default PageDoesntExist;
