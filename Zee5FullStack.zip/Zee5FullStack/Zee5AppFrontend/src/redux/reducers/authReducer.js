import {
  REGISTER_SUCCESS,
  REGISTER_FAIL,
  LOGIN_SUCCESS,
  USER_LOADED,
  LOGOUT,
  ACCOUNT_DELETED,
} from "../types";

const initialState = {
  token: null,
  isAuthenticated: false,
  loading: true,
  user: {},
};

// 1. token
// 2. user-Info
// 3. authentication status
// 4. loading: true or false ----> spinner
export default (state = initialState, action) => {
  const { type, payload } = action;

  // type = reducer flag. We can manipulate the state (global store).
  // payload = info to store it into store.
  switch (type) {
    case USER_LOADED:
      return { ...state, isAuthenticated: true, loading: false, user: payload };
    case REGISTER_SUCCESS:
      return { ...state, isAuthenticated: false, loading: true };
    case LOGIN_SUCCESS:
      localStorage.setItem("token", payload.accessToken);
      localStorage.setItem("userId", payload.userId);
      return {
        ...state,
        isAuthenticated: true,
        loading: false,
        user: payload,
      };
    case REGISTER_FAIL:
      localStorage.removeItem("token");
      return { ...state, isAuthenticated: false, loading: false, token: null };
    case ACCOUNT_DELETED:
    case LOGOUT:
      localStorage.removeItem("token");
      localStorage.removeItem("userId");
      return {
        ...state,
        isAuthenticated: false,
        loading: false,
        token: null,
        user: null,
      };

    default:
      return state;
  }
};
